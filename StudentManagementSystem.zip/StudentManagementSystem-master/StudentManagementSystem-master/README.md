# StudentManagementSystem
Java Swing based project with MySQL database developed using Netbeans IDE 
